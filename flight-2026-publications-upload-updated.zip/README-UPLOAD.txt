FLIGHT 2026 PUBLICATIONS — UPLOAD INSTRUCTIONS

1. Upload flight-2026-gallery.html to the ROOT of your GitHub repository:
   justin-gabis-portfolio/

2. Upload the folder:
   assets/flight-2026/

   It contains the 8 publication images in the approved sequence.

3. In index.html, replace the existing Flight 2026 work-card with the code in:
   INDEX-CHANGE-SNIPPET.html

4. Do not rename the image files unless you also update the paths in flight-2026-gallery.html.

5. The gallery uses the existing styles.css and adds page-specific CSS inside the new HTML file.
   You do NOT need to modify styles.css.

6. The 8 Facebook links are already assigned to the 8 images in sequence.
